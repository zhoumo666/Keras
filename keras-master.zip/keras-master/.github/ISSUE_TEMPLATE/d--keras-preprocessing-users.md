---
name: d) `keras.preprocessing` users
about: Select this if your issue is related to the `keras.preprocessing` module.

---


The [keras.preprocessing](https://github.com/keras-team/keras-preprocessing) module has been splitted from the main Keras repository.

Please submit your issue using this [link](https://github.com/keras-team/keras-preprocessing/issues/new/choose).

Thank you!
